
/**
 * @file course.c
 * @author Akash Santhaankrishnan (santhana@mcmaster.ca)
 * @brief Course library
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>



/**
 * @brief Accepts a course and a student, and enrolls the student into that course
 * 
 * @param course describes the course  
 * @param student describes the student
 * @returns Nothing
 * @see calloc() realloc()
 */
 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {

    // Allocating memory if the total number of students added is at one
    course->students = calloc(1, sizeof(Student));

  }
  else 
  {
    // Reallocating the memory if the total number of students is greater than one 
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the course that the students are enrolled in
 * 
 * @param course describes the course
 * @returns Nothing 
 * @see print_student()
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    // Prints all the student enrolled in the course
    print_student(&course->students[i]);
}




/**
 * @brief Provides the top student enrolled in the course via grade 
 * 
 * @param course describes the course 
 * @return Student* 
 * @see average()
 */

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 

  // Calculates the average of every student enrolled in the course and saves the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds how many students are passing a certain course and provides an array of them
 * 
 * @param course describes the course 
 * @param total_passing describes the total number of people passing the course 
 * @return Student* 
 * @see calloc() average()
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;


  // Calculating how many people in the course are passing the course 
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;


  // Allocating the memory to the number of people passing  

  passing = calloc(count, sizeof(Student));

  int j = 0;

  // Stores the averages of all the passing students into *passing
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}